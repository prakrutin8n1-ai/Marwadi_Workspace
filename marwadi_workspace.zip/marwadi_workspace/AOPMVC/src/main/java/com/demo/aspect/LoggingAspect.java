package com.demo.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

    // Runs before controller methods
    @Before("execution(* com.demo.controller..*(..))")
    public void beforeMethod() {

        System.out.println("AOP: Before controller method");
    }

    // Runs after controller methods
    @After("execution(* com.demo.controller..*(..))")
    public void afterMethod() {

        System.out.println("AOP: After controller method");
    }

    // Measures method execution time
    @Around("execution(* com.demo.controller..*(..))")
    public Object measureTime(ProceedingJoinPoint joinPoint)
            throws Throwable {

        long start = System.currentTimeMillis();

        try {
            return joinPoint.proceed();
        } finally {
            long end = System.currentTimeMillis();

            System.out.println(
                "AOP: Method " +
                joinPoint.getSignature().getName() +
                " executed in " + (end - start) + " ms"
            );
        }
    }
}
