
<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>

    <h2>Welcome to Dashboard</h2>

    <p>
        Hello, ${username}!
        You have logged in successfully.
    </p>

    <a href="logout">Logout</a>

</body>
</html>
