<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Student Login</title>
</head>
<body>

    <h2>Student Login</h2>

    <p style="color:red">${error}</p>
    <p style="color:green">${message}</p>

    <form action="login" method="post">
        Username:
        <input type="text" name="username" required>
        <br><br>

        Password:
        <input type="password" name="password" required>
        <br><br>

        <button type="submit">Login</button>
    </form>

    <p>
        New student?
        <a href="register">Register Here</a>
    </p>

</body>
</html>
