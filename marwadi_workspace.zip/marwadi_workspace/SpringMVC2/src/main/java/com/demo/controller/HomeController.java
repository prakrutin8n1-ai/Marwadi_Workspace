package com.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

    @GetMapping({"/", "/home"})
    public String home() {
        return "home";
    }

    @PostMapping("/submit")
    public String submit(
            @RequestParam("name") String name,
            @RequestParam("email") String email,
            Model model) {

        model.addAttribute("studentName", name);
        model.addAttribute("studentEmail", email);

        return "result";
    }
}